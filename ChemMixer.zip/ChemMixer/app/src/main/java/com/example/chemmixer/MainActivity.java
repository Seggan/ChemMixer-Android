package com.example.chemmixer;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
        EditText in;
        Button button;
        TextView lbl;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        in = findViewById(R.id.in);
        button = findViewById(R.id.button);
        lbl = findViewById(R.id.lbl);
    }
    public void sendMessage(View view){
        startActivity(new Intent(MainActivity.this, TempRequest.class));
    }
}
